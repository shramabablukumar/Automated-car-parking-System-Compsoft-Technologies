# Automated Parking System using ML

### Statement: "Design and Develop a automated parking system using ML , use pictures to detect the car numbers and allocate a parking spot "

#### Goal: Understand image detection of car number plate recognition and improve the accuracy.

#### Snapshots
![image](https://user-images.githubusercontent.com/67750128/193599214-e9015773-85db-45da-8f8b-1239e226ee75.png)

![image](https://user-images.githubusercontent.com/67750128/193599251-ab2091fa-91db-460b-a664-6132ce5fef14.png)

![image](https://user-images.githubusercontent.com/67750128/193599273-f5498dae-1a0b-47de-a3f2-602bbfc09d96.png)

![image](https://user-images.githubusercontent.com/67750128/193599355-74b26b5f-19c3-4b62-aa47-f0874e13c85d.png)







